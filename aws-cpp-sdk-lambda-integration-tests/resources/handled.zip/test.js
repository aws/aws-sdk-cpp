exports.handler = function(event, context) {
console.log("TESTTEST");
context.fail(event);
}
