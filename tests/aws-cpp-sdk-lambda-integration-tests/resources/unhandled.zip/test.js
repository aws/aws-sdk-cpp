exports.handler = function(event, context) {
console.log("TESTTEST");
// error is not defined.
context.fail(error);
}
