exports.handler = function(event, context) {
console.log("TESTTEST");
context.succeed(event);
}
